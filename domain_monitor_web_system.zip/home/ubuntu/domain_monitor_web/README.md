


## Implantação (Deployment)

Esta aplicação Next.js foi desenvolvida para ser implantada na plataforma Cloudflare Pages, que oferece um generoso nível gratuito.

### Pré-requisitos para Implantação

1.  **Conta Cloudflare:** Crie uma conta gratuita no [Cloudflare](https://dash.cloudflare.com/sign-up).
2.  **Repositório Git:** Envie o código-fonte desta aplicação para um repositório Git (GitHub, GitLab, Bitbucket).

### Passos para Implantação no Cloudflare Pages

1.  **Login no Cloudflare:** Acesse seu painel Cloudflare.
2.  **Navegue até Pages:** No menu lateral, vá para `Workers & Pages` > `Overview`.
3.  **Criar Aplicação:** Clique em `Create application` e depois na aba `Pages`.
4.  **Conectar ao Git:** Clique em `Connect to Git` e siga as instruções para conectar sua conta Git (GitHub, GitLab, etc.) e autorizar o Cloudflare a acessar seus repositórios.
5.  **Selecionar Repositório:** Escolha o repositório onde você enviou o código desta aplicação.
6.  **Configurar Build:**
    *   **Project name:** Escolha um nome para seu projeto (ex: `monitor-dominios`).
    *   **Production branch:** Selecione a branch principal do seu repositório (geralmente `main` ou `master`).
    *   **Framework preset:** Selecione `Next.js`.
    *   **Build command:** Geralmente `npm run build` ou `pnpm build` (verifique seu `package.json`).
    *   **Build output directory:** Geralmente `.next` ou `.open-next` (o template usado gera `.open-next`). Verifique a configuração do seu projeto.
7.  **Configurar Variáveis de Ambiente e Banco de Dados D1:**
    *   Vá para `Settings` > `Environment variables`.
    *   Adicione as variáveis de ambiente necessárias (se houver, além das configurações do D1).
    *   Vá para `Settings` > `Functions` > `D1 database bindings`.
    *   Clique em `Add binding`.
    *   **Variable name:** `DB` (conforme definido em `wrangler.toml`).
    *   **D1 Database:** Selecione um banco de dados D1 existente ou crie um novo (ex: `domain-monitor-prod`).
8.  **Salvar e Implantar:** Clique em `Save and Deploy`.
9.  **Aplicar Migrações no Banco de Dados de Produção:** Após a primeira implantação, você precisará aplicar as migrações ao banco de dados D1 de produção. Você pode fazer isso usando o Wrangler CLI no seu terminal local (conectado à sua conta Cloudflare):
    ```bash
    npx wrangler d1 migrations apply DB --remote
    ```
    Substitua `DB` pelo nome da sua variável de binding e certifique-se de que seu `wrangler.toml` esteja configurado para o ambiente de produção ou use os IDs corretos.

10. **Acessar Aplicação:** Após a conclusão da implantação, o Cloudflare fornecerá uma URL `.pages.dev` onde sua aplicação estará acessível.

### Configuração Adicional (Notificações por Email)

*   **Serviço de Email:** A função de envio de email (`sendEmail` em `/api/cron/check-domains/route.ts`) está atualmente simulada. Para enviar emails reais, você precisará:
    1.  Escolher um serviço de envio de email (ex: SendGrid, Mailgun, Resend). Muitos oferecem níveis gratuitos.
    2.  Obter uma chave de API (API Key) do serviço escolhido.
    3.  Adicionar a API Key como uma variável de ambiente segura no Cloudflare Pages (`Settings` > `Environment variables` > `Add variable` - marque como `Secret`).
    4.  Modificar a função `sendEmail` para usar a API do serviço de email escolhido, utilizando a chave de API configurada.

### Execução Agendada (Cron Triggers)

*   O arquivo `wrangler.toml` já inclui a configuração `[triggers] crons = ["0 3 * * *"]` para executar a verificação diária às 03:00 UTC. O Cloudflare Pages reconhecerá isso e chamará o endpoint `/api/cron/check-domains` automaticamente nesse horário. Certifique-se de que a lógica nesse endpoint esteja correta e que o envio de email (se configurado) funcione.

